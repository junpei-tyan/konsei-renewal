<?php
  /*
  Template Name: Experience Page
  */

  get_header(); 
?>

<!-- 【体験紹介】ページ -->

<?php get_footer(); ?>