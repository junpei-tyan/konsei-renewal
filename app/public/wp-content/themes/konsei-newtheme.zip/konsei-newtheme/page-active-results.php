<?php 
  /*
  Template Name: Active Results Page
  */

  get_header(); 
?>

<!-- 【活動実績】ページ -->

<?php get_footer(); ?>