<?php get_header(); ?>

<!-- トップページ -->

<?php get_footer(); ?>