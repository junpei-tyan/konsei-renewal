<?php 
  /*
  Template Name: Company Page
  */

  get_header(); 
?>

<!-- 【会社概要】ページ -->

<?php get_footer(); ?>