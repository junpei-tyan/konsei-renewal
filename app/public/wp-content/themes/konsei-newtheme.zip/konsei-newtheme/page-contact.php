<?php 
  /*
  Template Name: Contact Page
  */
  get_header(); 
?>

<!-- 【お問い合わせ】ページ -->

<?php get_footer(); ?>